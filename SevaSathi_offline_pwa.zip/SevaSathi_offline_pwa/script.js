// ---- SEVA SATHI ONLINE VERSION (Firebase Realtime DB) ----

// 1️⃣ Firebase configuration (replace with YOUR details from Firebase console)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID-default-rtdb.firebaseio.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MSG_ID",
  appId: "YOUR_APP_ID"
};

// 2️⃣ Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.database(app);

let currentRole = "";
let darkMode = false;

// Role selection
function setRole(role) {
  currentRole = role;
  document.getElementById('service').style.display = role === 'helper' ? 'block' : 'none';
}

// Register user to Firebase
function registerUser() {
  const name = document.getElementById('name').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const service = document.getElementById('service').value.trim();

  if (!currentRole) { alert("Please select role."); return; }
  if (!name || !phone) { alert("Please fill all fields."); return; }

  const user = { name, phone, service, role: currentRole, createdAt: Date.now() };
  const newRef = db.ref("users").push();
  newRef.set(user).then(() => {
    alert("Registered successfully!");
    if (currentRole === "customer") showCustomerPage();
    else clearInputs();
  }).catch(err => alert("Error: " + err.message));
}

function clearInputs(){
  document.getElementById('name').value="";
  document.getElementById('phone').value="";
  document.getElementById('service').value="";
}

// Display helpers list for customers
function showCustomerPage() {
  hideAllPages();
  document.getElementById('customerPage').style.display = 'block';
  const helperList = document.getElementById('helperList');
  helperList.innerHTML = '<p>Loading helpers...</p>';

  db.ref("users").orderByChild("role").equalTo("helper").on("value", snapshot => {
    helperList.innerHTML = "";
    snapshot.forEach(child => {
      const h = child.val();
      const div = document.createElement("div");
      div.innerHTML = `<strong>${h.name}</strong><br>
        Service: ${h.service || 'General'}<br>📞 ${h.phone}`;
      helperList.appendChild(div);
    });
  });
}

// Theme and pages
document.getElementById("themeBtn").onclick = () => {
  darkMode = !darkMode;
  document.body.classList.toggle("dark", darkMode);
};

document.getElementById("registerBtn").onclick = registerUser;
document.getElementById("menuBtn").onclick = () => {
  const sb = document.getElementById("sidebar");
  sb.style.display = sb.style.display === "flex" ? "none" : "flex";
};
document.getElementById("settingsBtn").onclick = () => { hideAllPages(); document.getElementById("settingsPage").style.display="block"; }
document.getElementById("aboutBtn").onclick = () => { hideAllPages(); document.getElementById("aboutPage").style.display="block"; }

function hideAllPages() {
  document.querySelectorAll(".page").forEach(p => p.style.display="none");
}

setTimeout(() => {
  document.getElementById("splash").style.display = "none";
  document.getElementById("main").style.display = "block";
}, 3000);